# Realistik 3D Minimalistik Portfolio

Minimalistik, diplomatik va realistik 3D portfolio.

## Texnologiya
- Three.js + OrbitControls
- Static hosting, Vercel ga tayyor
- UZ / RU / EN i18n

## Foydalanish
1. `data.json` ni CV, loyihalar, sertifikatlar bilan to‘ldir
2. `index.html` ni och yoki Vercel ga yukla

## Struktur
- index.html — 3D sahna + UI
- data.json — ko‘p tilli kontent

CV kiritilgandan keyin avtomatik yangilanadi.
